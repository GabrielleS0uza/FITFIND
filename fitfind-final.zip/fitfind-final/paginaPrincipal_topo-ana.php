<div class="form">
	<div class="row">
		<div class="col-1 p-2"></div>
		<div class="col-8 p-2"> <p class="titulo"><b>Ganhe</b> <b class="tit">%15 OFF</b> na primeira compra no APP</p></div>
		<div class="col-3 p-2"><p class="titulo" ><u>Baixe agora</u></p></div>
	</div>
</div>

		
	
 <nav class="navbar navbar-expand-sm navbar-light bg-light">
  <div class="container-fluid">
	<a class="navbar-brand" style="margin-left: 150px" href="javascript:void(0)"> <img src="Imagem1.png" width="70"   alt=""></a>
	<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
	  <span class="navbar-toggler-icon"></span>
	</button>
	<form class="d-flex">
		<input class="form-control me-2 col-sm-12 " style="margin-left: 30px" type="text" placeholder="Pesquisar">
		<button class="btn btn-outline-secondary" type="button">&#128269;</button>
	</form> 
	<div class="collapse navbar-collapse" id="mynavbar">
	  <ul class="navbar-nav me-auto">
		<li class="nav-item">
		  <a class="nav-link" style="margin-left: 500px" href="javascript:void(0)"><img src="icon2.png" width="50px"></a>
		</li>
		<li class="nav-item p-3">
		  <a class="nav-link" href="javascript:void(0)">Entre ou cadastre-se</a>
		</li>
	   </ul> 
	</div>  
  </div>
</nav>

<nav class="navbar navbar-expand-sm navbar-light bg-light">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" style="margin-left: 150px" id="mynavbar">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link" style="margin-left: 50px" href="javascript:void(0)">Ofertas</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" style="margin-left: 50px"href="javascript:void(0)">Novidades</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" style="margin-left: 50px" href="javascript:void(0)">Feminino</a>
        </li>
		    <li class="nav-item">
          <a class="nav-link" style="margin-left: 50px" href="javascript:void(0)">Maculino</a>
        </li>
		    <li class="nav-item">
          <a class="nav-link" style="margin-left: 50px" href="javascript:void(0)">Infantil</a>
        </li>
		    <li class="nav-item">
          <a class="nav-link" style="margin-left: 50px" href="javascript:void(0)">Esportivo</a>
        </li>
		    <li class="nav-item">
          <a class="nav-link" style="margin-left: 50px" href="javascript:void(0)">Marcas</a>
        </li>   
      </ul>
    </div>
  </div>
</nav>

<div class="form2"></div>

</body>
</html>