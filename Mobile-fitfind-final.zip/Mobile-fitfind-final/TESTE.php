<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sem título</title>
</head>

<body>
	
	<?php include_once('conexao.php');?>
	
	<div id="produtos"></div>
	<?php include_once("produtos.php")?>

</body>
</html>





