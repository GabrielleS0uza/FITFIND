<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sem título</title>
</head>

<body>
	
	

								<div class="row">
									<div class="col-sm-6" >	
								<p><label for="txtEmail">Email</label><br>
								<input type="text" placeholder="Informe o email:" name="txtEmail" id="txtEmail" class="form-control" ></p></div>
									<div class="col-sm-6">
										<label for="txtSenha">Senha</label>
										<input type="password" id="txtSenha" name="=txtSenha" class="form-control">
									</div>
									
								</div>
										
	
	
</body>
</html>